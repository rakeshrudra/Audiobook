import { MarqueeDirective } from './marquee.directive';

describe('MarqueeDirective', () => {
  it('should create an instance', () => {
    const directive = new MarqueeDirective();
    expect(directive).toBeTruthy();
  });
});
