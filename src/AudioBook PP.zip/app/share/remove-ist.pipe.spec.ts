import { RemoveISTPipe } from './remove-ist.pipe';

describe('RemoveISTPipe', () => {
  it('create an instance', () => {
    const pipe = new RemoveISTPipe();
    expect(pipe).toBeTruthy();
  });
});
