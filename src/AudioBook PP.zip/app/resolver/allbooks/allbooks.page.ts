import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allbooks',
  templateUrl: './allbooks.page.html',
  styleUrls: ['./allbooks.page.scss'],
})
export class AllbooksPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
