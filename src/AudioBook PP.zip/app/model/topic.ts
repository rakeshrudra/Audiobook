
export interface topic {
    id:string,
    book_id:string,
    chapter_id:string,
    topic:string,
    topicurdu:string,
    topicno:string,
    logo:string,
    status:string,
    color : string,
    isChecked : boolean,
    audiocount : any,
    newaudios : Array<string>

}
