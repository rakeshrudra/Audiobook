import { BooksearchPipe } from './booksearch.pipe';

describe('BooksearchPipe', () => {
  it('create an instance', () => {
    const pipe = new BooksearchPipe();
    expect(pipe).toBeTruthy();
  });
});
