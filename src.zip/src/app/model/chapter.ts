
export interface chapter {
    id:string,
    book_id:string,
    chapterno:string,
    chapter:string,
    chapterurdu : string,
    status:string,
    horizontal_img : string,
    logo : string,
    logo_min : string,
    audiocount : string,
    audiocountd : number,
    topiccount : string,
    color : string,
    downloadfilter : true,
    isChecked : boolean,
    audiodownloaded  : number,
    newaudios : Array<string>
}
