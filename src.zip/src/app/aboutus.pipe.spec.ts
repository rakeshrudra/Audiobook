import { AboutusPipe } from './aboutus.pipe';

describe('AboutusPipe', () => {
  it('create an instance', () => {
    const pipe = new AboutusPipe();
    expect(pipe).toBeTruthy();
  });
});
