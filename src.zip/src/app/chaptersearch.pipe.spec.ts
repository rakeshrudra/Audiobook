import { ChaptersearchPipe } from './chaptersearch.pipe';

describe('ChaptersearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ChaptersearchPipe();
    expect(pipe).toBeTruthy();
  });
});
