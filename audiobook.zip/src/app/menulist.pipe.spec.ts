import { MenulistPipe } from './menulist.pipe';

describe('MenulistPipe', () => {
  it('create an instance', () => {
    const pipe = new MenulistPipe();
    expect(pipe).toBeTruthy();
  });
});
