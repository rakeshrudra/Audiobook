import { AudiosearchPipe } from './audiosearch.pipe';

describe('AudiosearchPipe', () => {
  it('create an instance', () => {
    const pipe = new AudiosearchPipe();
    expect(pipe).toBeTruthy();
  });
});
